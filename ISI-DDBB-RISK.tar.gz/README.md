# ISI-DDBB-RISK

Git creado para documentar los pasos realizados para la implementación de la DDBB del Risk.

Recuperación de la parte de SQL.
